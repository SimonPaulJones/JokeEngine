template/css/style.scss should be compiled 
to 
template/css/min/style.css